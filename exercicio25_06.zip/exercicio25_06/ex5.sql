INSERT INTO Cliente (nome, email, senha, ativo, id_cidade) VALUES 
('Higor','oliveira.higor@gamil.com', '321senha', FALSE, 1),
('Malcer','eide.malcer@gamil.com', '321eide', FALSE, 5),
('Hugo Aparecido','aparecidode.hugo@gamil.com', '321senha', TRUE, 1),
('Eduardo Pereira','pereira.xavier@gamil.com', 'Dudu67', FALSE, 3),
('Murilo','varges.murilo@gamil.com', 'c3p0', TRUE, 3);