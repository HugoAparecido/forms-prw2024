INSERT INTO Cidade (nome, estado) VALUES 
('Piacatu','SP'),
('Birigui','SP'),
('Araçatuba','SP'),
('Rio de Janeiro','RJ'),
('Salvador','BA');